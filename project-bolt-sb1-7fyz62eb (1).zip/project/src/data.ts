export type Category = 'All' | 'Hot' | 'Iced' | 'Classic';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: Exclude<Category, 'All'>;
  badge?: string;
}

export const products: Product[] = [
  {
    id: 'cappuccino',
    name: 'Cappuccino',
    description:
      'A double shot of our house espresso under a velvet cloud of steamed milk, finished with a dusting of cocoa.',
    price: 1250,
    image:
      'https://images.pexels.com/photos/544113/pexels-photo-544113.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Hot',
    badge: 'Best Seller',
  },
  {
    id: 'spanish-latte',
    name: 'Spanish Latte',
    description:
      'Espresso mellowed with condensed milk and silky steamed milk — sweet, creamy and quietly addictive.',
    price: 1400,
    image:
      'https://images.pexels.com/photos/36851643/pexels-photo-36851643.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Hot',
    badge: 'Best Seller',
  },
  {
    id: 'caramel-macchiato',
    name: 'Caramel Macchiato',
    description:
      'Vanilla-kissed milk marked with espresso and ribbons of house-made salted caramel.',
    price: 1500,
    image:
      'https://images.pexels.com/photos/17558645/pexels-photo-17558645.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Iced',
  },
  {
    id: 'iced-americano',
    name: 'Iced Americano',
    description:
      'Bright and clean — espresso poured over spring water and ice, for those who like their coffee honest.',
    price: 1100,
    image:
      'https://images.pexels.com/photos/5741238/pexels-photo-5741238.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Iced',
  },
  {
    id: 'vanilla-latte',
    name: 'Vanilla Latte',
    description:
      'Smooth espresso, steamed milk and a whisper of Madagascan vanilla. Comfort in a cup.',
    price: 1400,
    image:
      'https://images.pexels.com/photos/339929/pexels-photo-339929.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Hot',
  },
  {
    id: 'mocha',
    name: 'Mocha',
    description:
      'Single-origin espresso meets 70% dark chocolate, crowned with softly whipped cream.',
    price: 1500,
    image:
      'https://images.pexels.com/photos/20854097/pexels-photo-20854097.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Classic',
  },
  {
    id: 'cold-brew',
    name: 'Cold Brew',
    description:
      'Steeped slow for 18 hours — naturally sweet, low in acidity, endlessly sippable.',
    price: 1300,
    image:
      'https://images.pexels.com/photos/38028988/pexels-photo-38028988.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Iced',
    badge: 'Best Seller',
  },
];

export const categories: Category[] = ['All', 'Hot', 'Iced', 'Classic'];

export const formatPrice = (amount: number) => `PKR ${new Intl.NumberFormat('en-PK').format(amount)}`;

export interface GalleryItem {
  image: string;
  alt: string;
  label: string;
  tall?: boolean;
}

export const gallery: GalleryItem[] = [
  {
    image:
      'https://images.pexels.com/photos/5151354/pexels-photo-5151354.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Barista pouring latte art',
    label: 'The Pour',
    tall: true,
  },
  {
    image:
      'https://images.pexels.com/photos/8218593/pexels-photo-8218593.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Glossy roasted coffee beans macro',
    label: 'The Bean',
  },
  {
    image:
      'https://images.pexels.com/photos/6612669/pexels-photo-6612669.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Barista pouring milk in a cozy cafe',
    label: 'The Craft',
  },
  {
    image:
      'https://images.pexels.com/photos/4921026/pexels-photo-4921026.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Hands holding a ceramic cup with latte art',
    label: 'The Moment',
  },
  {
    image:
      'https://images.pexels.com/photos/37838325/pexels-photo-37838325.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Warm inviting cafe interior with wooden furniture and plants',
    label: 'The Room',
  },
  {
    image:
      'https://images.pexels.com/photos/14747990/pexels-photo-14747990.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Chemex coffee maker with a glass cup',
    label: 'The Ritual',
    tall: true,
  },
  {
    image:
      'https://images.pexels.com/photos/15801079/pexels-photo-15801079.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Hands creating intricate latte art',
    label: 'The Detail',
  },
  {
    image:
      'https://images.pexels.com/photos/302898/pexels-photo-302898.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Barista making espresso with a coffee machine',
    label: 'The Machine',
  },
];

export const HERO_IMAGE =
  'https://images.pexels.com/photos/37417627/pexels-photo-37417627.jpeg?auto=compress&cs=tinysrgb&w=1200';

export const STORY_IMAGES = [
  'https://images.pexels.com/photos/69975/pexels-photo-69975.jpeg?auto=compress&cs=tinysrgb&w=900',
  'https://images.pexels.com/photos/4349811/pexels-photo-4349811.jpeg?auto=compress&cs=tinysrgb&w=900',
];
