import { useState } from 'react';
import { MapPin, Clock, Phone, Mail, Send, CheckCircle2 } from 'lucide-react';
import Reveal from './Reveal';

const hours = [
  { day: 'Monday — Friday', time: '7:00 AM — 7:00 PM' },
  { day: 'Saturday', time: '8:00 AM — 8:00 PM' },
  { day: 'Sunday', time: '8:00 AM — 5:00 PM' },
];

export default function Contact() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
  };

  return (
    <section id="contact" className="bg-cream py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-14 lg:grid-cols-2 lg:gap-20">
          <div>
            <Reveal>
              <p className="eyebrow">Visit Us</p>
              <h2 className="mt-3 font-display text-4xl font-semibold text-forest sm:text-5xl">
                Come Say <span className="italic text-coffee">Hello</span>
              </h2>
              <p className="mt-5 max-w-md text-[15px] font-light leading-relaxed text-forest/65">
                The kettle is always on. Drop by for a cup, stay for the calm —
                we'd love to show you around the roastery.
              </p>
            </Reveal>

            <Reveal delay={120}>
              <div className="mt-10 space-y-6">
                <div className="flex gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-forest text-pistachio">
                    <MapPin className="h-5 w-5" strokeWidth={1.7} />
                  </div>
                  <div>
                    <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-forest/50">
                      Find Us
                    </h3>
                    <p className="mt-1 font-serif text-lg text-forest">
                      12 Fernwood Lane, Portland, OR 97209
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-forest text-pistachio">
                    <Clock className="h-5 w-5" strokeWidth={1.7} />
                  </div>
                  <div>
                    <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-forest/50">
                      Opening Hours
                    </h3>
                    <ul className="mt-1 space-y-1">
                      {hours.map((h) => (
                        <li key={h.day} className="flex gap-4 text-[15px] text-forest/80">
                          <span className="w-40 font-serif">{h.day}</span>
                          <span className="font-medium text-coffee">{h.time}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-forest text-pistachio">
                    <Phone className="h-5 w-5" strokeWidth={1.7} />
                  </div>
                  <div>
                    <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-forest/50">
                      Call Us
                    </h3>
                    <p className="mt-1 font-serif text-lg text-forest">+1 (503) 555-0142</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-forest text-pistachio">
                    <Mail className="h-5 w-5" strokeWidth={1.7} />
                  </div>
                  <div>
                    <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-forest/50">
                      Email
                    </h3>
                    <p className="mt-1 font-serif text-lg text-forest">hello@mossandmug.com</p>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>

          <Reveal delay={200}>
            <div className="flex h-full flex-col overflow-hidden rounded-3xl bg-forest p-8 text-cream shadow-xl shadow-forest/20 sm:p-12">
              <div className="flex-1">
                <h3 className="font-display text-3xl font-semibold">
                  Join the <span className="italic text-pistachio">Inner Circle</span>
                </h3>
                <p className="mt-3 text-sm font-light leading-relaxed text-cream/70">
                  New roasts, secret menu drops and members-only tastings —
                  one beautiful email a week, never more.
                </p>

                {subscribed ? (
                  <div className="mt-8 flex items-start gap-3 rounded-2xl bg-pistachio/15 p-5">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-pistachio" />
                    <div>
                      <p className="font-serif text-lg font-semibold text-pistachio">
                        Welcome to the circle.
                      </p>
                      <p className="mt-1 text-[13px] text-cream/70">
                        Check your inbox — your first pour of good news is brewing.
                      </p>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubscribe} className="mt-8">
                    <label htmlFor="newsletter-email" className="sr-only">
                      Email address
                    </label>
                    <div className="flex flex-col gap-3 sm:flex-row">
                      <input
                        id="newsletter-email"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@example.com"
                        className="flex-1 rounded-full border border-cream/20 bg-forest-deep/70 px-5 py-3.5 text-sm text-cream outline-none transition-colors placeholder:text-cream/40 focus:border-pistachio"
                      />
                      <button
                        type="submit"
                        className="inline-flex items-center justify-center gap-2 rounded-full bg-pistachio px-7 py-3.5 text-[12px] font-semibold uppercase tracking-[0.18em] text-forest-deep transition-all duration-300 hover:bg-cream hover:shadow-lg"
                      >
                        Subscribe
                        <Send className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <p className="mt-3 text-[11px] text-cream/40">
                      No spam, ever. Unsubscribe anytime.
                    </p>
                  </form>
                )}
              </div>

              <div className="mt-10 overflow-hidden rounded-2xl">
                <img
                  src="https://images.pexels.com/photos/18721993/pexels-photo-18721993.jpeg?auto=compress&cs=tinysrgb&w=900"
                  alt="Elegant cafe interior with plants and warm lighting"
                  loading="lazy"
                  className="h-44 w-full object-cover transition-transform duration-700 hover:scale-105"
                />
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
