import { Flame, Plus } from 'lucide-react';
import Reveal from './Reveal';
import { products, formatPrice } from '../data';
import { useCart } from '../context/CartContext';

export default function BestSellers() {
  const { add } = useCart();
  const bestSellers = products.filter((p) => p.badge === 'Best Seller').slice(0, 3);

  return (
    <section id="shop" className="relative bg-softwhite py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <Reveal>
            <p className="eyebrow">Most Loved</p>
            <h2 className="mt-3 font-display text-4xl font-semibold text-forest sm:text-5xl">
              This Week's <span className="italic text-coffee">Best Sellers</span>
            </h2>
          </Reveal>
          <Reveal delay={150}>
            <a
              href="#menu"
              className="group inline-flex items-center gap-2 text-[12px] font-medium uppercase tracking-[0.2em] text-forest transition-colors hover:text-coffee"
            >
              View Full Menu
              <span className="h-px w-8 bg-current transition-all duration-300 group-hover:w-12" />
            </a>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {bestSellers.map((product, i) => (
            <Reveal key={product.id} delay={i * 120}>
              <article className="group relative">
                <div className="card-img relative aspect-[4/5]">
                  <img
                    src={product.image}
                    alt={product.name}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.06]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-forest-deep/40 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                  <span className="absolute left-4 top-4 flex items-center gap-1.5 rounded-full bg-softwhite/95 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.15em] text-coffee shadow-sm">
                    <Flame className="h-3 w-3" />
                    Best Seller
                  </span>
                  <button
                    onClick={() => add(product)}
                    aria-label={`Add ${product.name} to cart`}
                    className="absolute bottom-4 right-4 flex h-12 w-12 translate-y-3 items-center justify-center rounded-full bg-forest text-cream opacity-0 shadow-lg transition-all duration-500 hover:scale-110 hover:bg-forest-deep group-hover:translate-y-0 group-hover:opacity-100"
                  >
                    <Plus className="h-5 w-5" strokeWidth={2} />
                  </button>
                </div>
                <div className="mt-5 flex items-start justify-between gap-4 px-1">
                  <div>
                    <h3 className="font-serif text-2xl font-semibold text-forest">
                      {product.name}
                    </h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-forest/55">
                      {product.description}
                    </p>
                  </div>
                  <span className="shrink-0 font-display text-xl font-semibold text-coffee">
                    {formatPrice(product.price)}
                  </span>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
