import { useState } from 'react';
import { X, CheckCircle2, Coffee } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useStreak } from '../context/StreakContext';
import { formatPrice } from '../data';

export default function CheckoutModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { lines, total, grandTotal, discount, promoCode, clear, closeCart, showToast } = useCart();
  const { logCoffees } = useStreak();
  const [step, setStep] = useState<'details' | 'success'>('details');
  const [name, setName] = useState('');
  const [orderNo, setOrderNo] = useState('');

  if (!open) return;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setOrderNo(`MM-${Math.floor(10000 + Math.random() * 89999)}`);
    setStep('success');
    logCoffees(lines.reduce((s, l) => s + l.qty, 0));
    clear();
  };

  const handleClose = () => {
    onClose();
    closeCart();
    setTimeout(() => {
      setStep('details');
      setName('');
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-forest-deep/70 backdrop-blur-sm" onClick={handleClose} />
      <div className="animate-toast-in relative w-full max-w-md overflow-hidden rounded-3xl bg-softwhite shadow-2xl">
        <button
          onClick={handleClose}
          aria-label="Close checkout"
          className="absolute right-4 top-4 z-10 rounded-full bg-softwhite/80 p-2 text-forest transition-colors hover:bg-cream"
        >
          <X className="h-5 w-5" strokeWidth={1.8} />
        </button>

        {step === 'details' ? (
          <>
            <div className="bg-forest px-8 pb-8 pt-10 text-center text-cream">
              <Coffee className="mx-auto h-8 w-8 text-pistachio" strokeWidth={1.5} />
              <h2 className="mt-3 font-display text-2xl font-semibold">Almost there</h2>
              <p className="mt-1 text-sm text-cream/70">
                {lines.reduce((s, l) => s + l.qty, 0)} item(s)
                {discount > 0 && promoCode ? (
                  <>
                    {' '}· <span className="font-semibold text-pistachio line-through">{formatPrice(total)}</span>{' '}
                    <span className="font-semibold text-pistachio">{formatPrice(grandTotal)}</span>
                    {' '}with {promoCode}
                  </>
                ) : (
                  <> · {formatPrice(total)}</>
                )}
                , pickup in store
              </p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4 px-8 py-8">
              <div>
                <label htmlFor="co-name" className="eyebrow mb-1.5 block">
                  Your name
                </label>
                <input
                  id="co-name"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Alex Morgan"
                  className="w-full rounded-xl border border-forest/15 bg-cream/50 px-4 py-3 text-sm text-forest outline-none transition-colors placeholder:text-forest/35 focus:border-sage focus:bg-cream"
                />
              </div>
              <div>
                <label htmlFor="co-time" className="eyebrow mb-1.5 block">
                  Pickup time
                </label>
                <select
                  id="co-time"
                  className="w-full rounded-xl border border-forest/15 bg-cream/50 px-4 py-3 text-sm text-forest outline-none transition-colors focus:border-sage focus:bg-cream"
                >
                  <option>As soon as possible (~10 min)</option>
                  <option>In 30 minutes</option>
                  <option>In 1 hour</option>
                </select>
              </div>
              <div>
                <label htmlFor="co-note" className="eyebrow mb-1.5 block">
                  Note to barista <span className="normal-case tracking-normal text-forest/40">(optional)</span>
                </label>
                <textarea
                  id="co-note"
                  rows={2}
                  placeholder="Oat milk, extra hot, less sweet…"
                  className="w-full resize-none rounded-xl border border-forest/15 bg-cream/50 px-4 py-3 text-sm text-forest outline-none transition-colors placeholder:text-forest/35 focus:border-sage focus:bg-cream"
                />
              </div>
              <button type="submit" className="btn-primary w-full">
                Place Order — {formatPrice(grandTotal)}
              </button>
              <p className="text-center text-[11px] text-forest/40">
                This is a demo checkout — no payment is taken.
              </p>
            </form>
          </>
        ) : (
          <div className="px-8 py-12 text-center">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-pistachio/40">
              <CheckCircle2 className="h-10 w-10 text-forest" strokeWidth={1.5} />
            </div>
            <h2 className="mt-6 font-display text-3xl font-semibold text-forest">
              Order confirmed
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-forest/60">
              Thank you{name ? `, ${name.split(' ')[0]}` : ''}! Your order{' '}
              <span className="font-semibold text-coffee">{orderNo}</span> is being prepared.
              We'll call your name at the counter — ready in about 10 minutes.
            </p>
            <div className="mt-8 rounded-2xl bg-cream px-6 py-4">
              <p className="text-[11px] uppercase tracking-[0.25em] text-forest/50">
                Slow coffee. Better moments.
              </p>
            </div>
            <button onClick={handleClose} className="btn-primary mt-8 w-full">
              Back to Browsing
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
