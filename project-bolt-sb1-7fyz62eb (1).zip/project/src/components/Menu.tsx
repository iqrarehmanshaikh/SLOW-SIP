import { useState } from 'react';
import { Plus } from 'lucide-react';
import Reveal from './Reveal';
import { products, categories, formatPrice } from '../data';
import type { Category } from '../data';
import { useCart } from '../context/CartContext';

export default function Menu() {
  const [active, setActive] = useState<Category>('All');
  const { add } = useCart();

  const filtered =
    active === 'All' ? products : products.filter((p) => p.category === active);

  return (
    <section id="menu" className="relative bg-cream py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="text-center">
          <p className="eyebrow">The Menu</p>
          <h2 className="mx-auto mt-3 max-w-2xl font-display text-4xl font-semibold text-forest sm:text-5xl">
            Crafted Cup by <span className="italic text-coffee">Cup</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-forest/60 sm:text-base">
            Every drink starts with beans roasted in small batches and ends with
            a barista who cares. Pick your moment.
          </p>
        </Reveal>

        <Reveal delay={150} className="mt-10 flex justify-center">
          <div className="no-scrollbar flex max-w-full gap-1.5 overflow-x-auto rounded-full border border-forest/10 bg-softwhite p-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActive(cat)}
                className={`shrink-0 rounded-full px-5 py-2.5 text-[12px] font-medium uppercase tracking-[0.15em] transition-all duration-300 ${
                  active === cat
                    ? 'bg-forest text-cream shadow-sm'
                    : 'text-forest/60 hover:bg-cream hover:text-forest'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="mt-14 grid gap-x-10 gap-y-6 lg:grid-cols-2">
          {filtered.map((product, i) => (
            <Reveal key={product.id} delay={Math.min(i * 60, 240)}>
              <article className="group flex items-center gap-5 rounded-2xl bg-softwhite p-4 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-forest/10">
                <div className="h-24 w-24 shrink-0 overflow-hidden rounded-xl sm:h-28 sm:w-28">
                  <img
                    src={product.image}
                    alt={product.name}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-3">
                    <h3 className="truncate font-serif text-xl font-semibold text-forest sm:text-2xl">
                      {product.name}
                    </h3>
                    <span className="shrink-0 font-display text-lg font-semibold text-coffee">
                      {formatPrice(product.price)}
                    </span>
                  </div>
                  <div className="mt-1.5 h-px flex-1 bg-gradient-to-r from-transparent via-forest/15 to-transparent" />
                  <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-forest/55">
                    {product.description}
                  </p>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-sage-dark">
                      {product.category}
                    </span>
                    <button
                      onClick={() => add(product)}
                      className="inline-flex items-center gap-1.5 rounded-full border border-forest/20 px-4 py-1.5 text-[11px] font-medium uppercase tracking-[0.15em] text-forest transition-all duration-300 hover:border-forest hover:bg-forest hover:text-cream"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      Add
                    </button>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
