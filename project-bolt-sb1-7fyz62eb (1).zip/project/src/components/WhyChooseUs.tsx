import { Coffee, Bean, Gem, HeartHandshake } from 'lucide-react';
import Reveal from './Reveal';

const reasons = [
  {
    icon: Coffee,
    title: 'Freshly Brewed',
    text: 'Nothing sits. Every cup is brewed to order, seconds after you ask for it.',
  },
  {
    icon: Bean,
    title: 'Premium Coffee Beans',
    text: 'Single-origin and seasonal lots, cupped and scored at 84+ before they make the menu.',
  },
  {
    icon: Gem,
    title: 'Quality Ingredients',
    text: 'Real vanilla, stone-ground chocolate and milk from a dairy thirty miles away.',
  },
  {
    icon: HeartHandshake,
    title: 'Made with Love',
    text: 'The difference you can taste is the care we put in — every shift, every cup.',
  },
];

export default function WhyChooseUs() {
  return (
    <section className="relative overflow-hidden bg-forest py-24 sm:py-32">
      <div
        className="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full opacity-[0.07]"
        style={{ background: 'radial-gradient(circle, #C7D2A3 0%, transparent 70%)' }}
      />
      <div
        className="pointer-events-none absolute -bottom-40 -left-24 h-96 w-96 rounded-full opacity-[0.07]"
        style={{ background: 'radial-gradient(circle, #C7D2A3 0%, transparent 70%)' }}
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="text-center">
          <p className="text-[11px] font-medium uppercase tracking-[0.3em] text-pistachio">
            Why Choose Us
          </p>
          <h2 className="mx-auto mt-3 max-w-2xl font-display text-4xl font-semibold text-cream sm:text-5xl">
            The Details Make <span className="italic text-pistachio">the Difference</span>
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {reasons.map(({ icon: Icon, title, text }, i) => (
            <Reveal key={title} delay={i * 100}>
              <div className="group h-full rounded-2xl border border-cream/10 bg-forest-deep/60 p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-pistachio/30 hover:bg-forest-deep">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-pistachio/15 text-pistachio transition-all duration-500 group-hover:bg-pistachio group-hover:text-forest-deep">
                  <Icon className="h-5 w-5" strokeWidth={1.6} />
                </div>
                <h3 className="mt-5 font-serif text-xl font-semibold text-cream">{title}</h3>
                <p className="mt-2.5 text-[13px] font-light leading-relaxed text-cream/60">
                  {text}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
