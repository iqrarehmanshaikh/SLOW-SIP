import { Instagram, ArrowUpRight } from 'lucide-react';
import Reveal from './Reveal';
import { gallery } from '../data';

export default function Gallery() {
  return (
    <section id="gallery" className="bg-softwhite py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <Reveal>
            <p className="eyebrow">The Gallery</p>
            <h2 className="mt-3 max-w-xl font-display text-4xl font-semibold text-forest sm:text-5xl">
              Moments in <span className="italic text-coffee">Coffee</span>
            </h2>
          </Reveal>
          <Reveal delay={150}>
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 text-[12px] font-medium uppercase tracking-[0.2em] text-forest transition-colors hover:text-coffee"
            >
              <Instagram className="h-4 w-4" />
              @mossandmug
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </Reveal>
        </div>

        <div className="mt-14 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          {gallery.map((item, i) => (
            <Reveal key={item.image} delay={Math.min(i * 70, 280)}>
              <figure
                className={`group relative overflow-hidden rounded-2xl ${
                  item.tall ? 'aspect-[3/4] lg:row-span-2' : 'aspect-square'
                }`}
              >
                <img
                  src={item.image}
                  alt={item.alt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.07]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-forest-deep/70 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                <figcaption className="absolute bottom-4 left-4 translate-y-2 font-serif text-lg italic text-cream opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                  {item.label}
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
