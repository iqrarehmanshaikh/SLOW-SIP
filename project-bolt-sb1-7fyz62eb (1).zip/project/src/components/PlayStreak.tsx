import { useState } from 'react';
import { Flame, Coffee, Award, Sparkles, RotateCcw, Copy, Check } from 'lucide-react';
import Reveal from './Reveal';
import {
  useStreak,
  levelOf,
  levelStyles,
  levelText,
  buildGrid,
  weekDays,
  fromKey,
} from '../context/StreakContext';

const WEEKS = 26;

function GridTooltip({ cell }: { cell: { key: string; count: number } }) {
  const date = fromKey(cell.key);
  const label = date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
  return (
    <div className="pointer-events-none absolute bottom-full left-1/2 z-20 mb-2 -translate-x-1/2 whitespace-nowrap rounded-lg bg-forest-deep px-3 py-2 text-[11px] font-medium text-cream opacity-0 shadow-lg transition-opacity duration-150 group-hover:opacity-100">
      {label} · {levelText[levelOf(cell.count)]}
    </div>
  );
}

export default function PlayStreak() {
  const {
    days,
    todayCount,
    logCoffees,
    simulateDemo,
    resetDemo,
    currentStreak,
    totalCoffees,
    week,
    weekDone,
    promoCode,
  } = useStreak();
  const [copied, setCopied] = useState(false);

  const { columns, monthLabels } = buildGrid(WEEKS);

  const copyPromo = async () => {
    try {
      await navigator.clipboard.writeText(promoCode ?? '');
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
  };

  return (
    <section id="play" className="relative overflow-hidden bg-cream py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="text-center">
          <p className="eyebrow">Play &amp; Streak</p>
          <h2 className="mx-auto mt-3 max-w-2xl font-display text-4xl font-semibold text-forest sm:text-5xl">
            Your Coffee <span className="italic text-coffee">Ritual, Rewarded</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-forest/60 sm:text-base">
            Every order lands on your streak board. Show up Monday through Saturday
            and the week's reward is yours.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-8 lg:grid-cols-5">
          {/* ── Weekly Ritual Tracker + Reward ─────────────────────────── */}
          <Reveal className="lg:col-span-2" delay={100}>
            <div className="flex h-full flex-col rounded-3xl bg-forest p-7 text-cream shadow-xl shadow-forest/15 sm:p-9">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-xl font-semibold sm:text-2xl">
                  Weekly Ritual Tracker
                </h3>
                <span className="rounded-full bg-pistachio/15 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-pistachio">
                  Mon – Sat
                </span>
              </div>

              <div className="mt-7 grid grid-cols-6 gap-2">
                {weekDays.map((day, i) => (
                  <div key={day} className="flex flex-col items-center gap-2">
                    <div
                      className={`flex h-10 w-10 items-center justify-center rounded-full border text-[11px] font-semibold transition-all duration-500 sm:h-11 sm:w-11 ${
                        week[i]
                          ? 'border-pistachio bg-pistachio text-forest-deep shadow-md shadow-pistachio/30'
                          : 'border-cream/20 text-cream/40'
                      }`}
                    >
                      {week[i] ? <Check className="h-4 w-4" strokeWidth={3} /> : day.slice(0, 1)}
                    </div>
                    <span
                      className={`text-[9px] font-medium uppercase tracking-wider sm:text-[10px] ${
                        week[i] ? 'text-pistachio' : 'text-cream/40'
                      }`}
                    >
                      {day}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-7 border-t border-cream/10 pt-6">
                {weekDone && promoCode ? (
                  <div className="animate-toast-in rounded-2xl bg-pistachio p-5 text-forest-deep">
                    <div className="flex items-center gap-2.5">
                      <Award className="h-6 w-6" strokeWidth={1.8} />
                      <p className="font-display text-lg font-semibold leading-tight">
                        50% OFF Weekly Ritual Reward Unlocked
                      </p>
                    </div>
                    <button
                      onClick={copyPromo}
                      className="mt-4 flex w-full items-center justify-between rounded-xl border-2 border-dashed border-forest-deep/40 bg-softwhite/60 px-4 py-3 transition-colors hover:bg-softwhite"
                    >
                      <span className="font-mono text-base font-bold tracking-[0.2em]">
                        {promoCode}
                      </span>
                      <span className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.15em]">
                        {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                        {copied ? 'Copied' : 'Copy'}
                      </span>
                    </button>
                    <p className="mt-3 text-[11px] font-medium leading-relaxed text-forest-deep/70">
                      Automatically applied at checkout in the cart. Resets next week — keep the ritual going.
                    </p>
                  </div>
                ) : (
                  <div className="rounded-2xl border border-dashed border-cream/25 p-5">
                    <div className="flex items-center gap-2.5 text-cream/80">
                      <Sparkles className="h-5 w-5 text-pistachio" strokeWidth={1.8} />
                      <p className="font-display text-lg font-semibold">
                        50% OFF Weekly Reward
                      </p>
                    </div>
                    <p className="mt-2 text-[13px] leading-relaxed text-cream/60">
                      Order at least one coffee every day from Monday to Saturday to
                      unlock <span className="font-semibold text-pistachio">RITUAL50</span> —
                      half off your order in the cart.
                    </p>
                    <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-cream/10">
                      <div
                        className="h-full rounded-full bg-pistachio transition-all duration-700"
                        style={{ width: `${(week.filter(Boolean).length / 6) * 100}%` }}
                      />
                    </div>
                    <p className="mt-2 text-right text-[11px] font-medium text-cream/50">
                      {week.filter(Boolean).length}/6 days
                    </p>
                  </div>
                )}
              </div>

              {/* Demo controls */}
              <div className="mt-auto flex flex-wrap gap-3 pt-7">
                <button
                  onClick={simulateDemo}
                  className="inline-flex items-center gap-2 rounded-full bg-cream px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.15em] text-forest transition-all duration-300 hover:bg-pistachio"
                >
                  <Flame className="h-3.5 w-3.5" />
                  Demo Mon–Sat Streak
                </button>
                <button
                  onClick={resetDemo}
                  className="inline-flex items-center gap-2 rounded-full border border-cream/25 px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.15em] text-cream/70 transition-all duration-300 hover:border-cream hover:text-cream"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Reset
                </button>
              </div>
            </div>
          </Reveal>

          {/* ── Contribution Grid ──────────────────────────────────────── */}
          <Reveal className="lg:col-span-3" delay={200}>
            <div className="flex h-full flex-col rounded-3xl bg-softwhite p-7 shadow-sm shadow-forest/10 sm:p-9">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <h3 className="font-display text-xl font-semibold text-forest sm:text-2xl">
                    Coffee Streak Board
                  </h3>
                  <p className="mt-1 text-[13px] text-forest/55">
                    Six months of cups, one square per day.
                  </p>
                </div>
                <div className="flex gap-5">
                  <div className="text-center">
                    <p className="font-display text-2xl font-semibold text-coffee sm:text-3xl">
                      {currentStreak}
                    </p>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-forest/45">
                      Day Streak
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="font-display text-2xl font-semibold text-coffee sm:text-3xl">
                      {totalCoffees}
                    </p>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-forest/45">
                      Coffees Logged
                    </p>
                  </div>
                </div>
              </div>

              <div className="no-scrollbar mt-7 overflow-x-auto pb-1">
                <div className="min-w-[560px]">
                  {/* Month labels */}
                  <div className="flex gap-[3px] pl-9">
                    {columns.map((_, w) => {
                      const label = monthLabels.find((m) => m.index === w);
                      return (
                        <div
                          key={w}
                          className="relative w-[13px] text-[9px] font-medium uppercase tracking-wide text-forest/45"
                        >
                          {label && <span className="absolute left-0 whitespace-nowrap">{label.label}</span>}
                        </div>
                      );
                    })}
                  </div>
                  <div className="mt-1 flex gap-[3px]">
                    {/* Day labels */}
                    <div className="flex w-9 shrink-0 flex-col gap-[3px] pr-1.5 text-right">
                      {['Mon', 'Wed', 'Fri'].map((d, i) => (
                        <div key={d} className="flex flex-col gap-[3px]">
                          <span className="h-[13px] text-[9px] leading-[13px] font-medium text-forest/45">{d}</span>
                          {i < 2 && <span className="h-[13px]" />}
                        </div>
                      ))}
                    </div>
                    {/* Cells */}
                    {columns.map((col) => (
                      <div key={col[0]?.key ?? col} className="flex flex-col gap-[3px]">
                        {col.map((cell) => {
                          const count = days[cell.key] ?? 0;
                          const level = levelOf(count);
                          return (
                            <div key={cell.key} className="group relative">
                              <div
                                className={`h-[13px] w-[13px] rounded-[3px] transition-transform duration-150 hover:scale-125 ${levelStyles[level]} ${
                                  cell.future ? 'opacity-25' : ''
                                } ${count > 0 ? 'ring-1 ring-forest/10' : ''}`}
                              />
                              {!cell.future && <GridTooltip cell={{ key: cell.key, count }} />}
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Legend + today logging */}
              <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-forest/10 pt-5">
                <div className="flex items-center gap-2 text-[10px] text-forest/50">
                  <span className="font-medium uppercase tracking-wider">Less</span>
                  {([0, 1, 2, 3] as const).map((l) => (
                    <span key={l} className={`h-[13px] w-[13px] rounded-[3px] ${levelStyles[l]}`} />
                  ))}
                  <span className="font-medium uppercase tracking-wider">More</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[11px] font-medium uppercase tracking-[0.15em] text-forest/50">
                    Today: {todayCount} {todayCount === 1 ? 'coffee' : 'coffees'}
                  </span>
                  <button
                    onClick={() => logCoffees(1)}
                    className="inline-flex items-center gap-1.5 rounded-full bg-forest px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.15em] text-cream transition-all duration-300 hover:bg-forest-deep hover:scale-[1.03]"
                  >
                    <Coffee className="h-3.5 w-3.5" />
                    Check In
                  </button>
                </div>
              </div>
              <p className="mt-3 text-[11px] leading-relaxed text-forest/40">
                Every completed checkout in the cart is logged to today's square automatically.
              </p>
            </div>
          </Reveal>
        </div>

        <StickerWall />
      </div>
    </section>
  );
}

/* ── Part B: Sticker Wall ─────────────────────────────────────────────── */

import { Pin } from 'lucide-react';
import { stickers } from '../context/StreakContext';
import type { Sticker } from '../context/StreakContext';


function StickerArt({ kind }: { kind: string }) {
  // simple SVG motifs per persona
  switch (kind) {
    case 'iced-latte-lover':
      return (
        <svg viewBox="0 0 48 48" className="h-10 w-10" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <rect x="14" y="12" width="20" height="26" rx="4" />
          <line x1="12" y1="20" x2="36" y2="20" />
          <line x1="30" y1="6" x2="26" y2="12" />
          <path d="M20 26c2 2 6 2 8 0" />
        </svg>
      );
    case 'espresso-purist':
      return (
        <svg viewBox="0 0 48 48" className="h-10 w-10" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <path d="M10 18h22v10a10 10 0 0 1-10 10h-2a10 10 0 0 1-10-10V18z" />
          <path d="M32 20h4a4 4 0 0 1 0 8h-4" />
          <line x1="16" y1="10" x2="18" y2="14" />
          <line x1="24" y1="8" x2="24" y2="14" />
        </svg>
      );
    case 'midnight-cold-brew':
      return (
        <svg viewBox="0 0 48 48" className="h-10 w-10" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <path d="M16 8h16l-2 30a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4L16 8z" />
          <line x1="17" y1="22" x2="31" y2="22" />
          <circle cx="24" cy="32" r="1.5" fill="currentColor" />
        </svg>
      );
    case 'morning-ritualist':
      return (
        <svg viewBox="0 0 48 48" className="h-10 w-10" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <circle cx="24" cy="28" r="10" />
          <path d="M24 6v6M38 14l-4 4M10 14l4 4M42 28h-4M10 28H6" />
          <path d="M20 28c1 2 7 2 8 0" />
        </svg>
      );
    case 'roast-explorer':
      return (
        <svg viewBox="0 0 48 48" className="h-10 w-10" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <ellipse cx="24" cy="24" rx="10" ry="14" transform="rotate(25 24 24)" />
          <path d="M22 14c4 4 4 16 0 20" />
        </svg>
      );
    case 'latte-art-aficionado':
      return (
        <svg viewBox="0 0 48 48" className="h-10 w-10" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <circle cx="24" cy="24" r="14" />
          <path d="M24 12c3 4 3 8 0 12-3-4-3-8 0-12zM24 24c3 4 3 8 0 12-3-4-3-8 0-12zM14 22c4 1 8 1 10 2M34 22c-4 1-8 1-10 2" strokeWidth="1.5" />
        </svg>
      );
    default: // cafe-regular
      return (
        <svg viewBox="0 0 48 48" className="h-10 w-10" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <path d="M12 18h20v9a9 9 0 0 1-9 9h-2a9 9 0 0 1-9-9v-9z" />
          <path d="M32 20h3a4 4 0 0 1 0 8h-3" />
          <path d="M17 10c1 2 1 4 0 6M24 10c1 2 1 4 0 6" />
        </svg>
      );
  }
}

function StickerChip({ sticker, pinned, onToggle }: { sticker: Sticker; pinned: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      aria-pressed={pinned}
      className={`group relative outline-none transition-all duration-300 ${
        pinned ? 'z-10 scale-105' : 'hover:z-10 hover:scale-105 hover:rotate-0'
      }`}
      style={{ transform: `rotate(${pinned ? sticker.rotation * 0.4 : sticker.rotation}deg)` }}
    >
      <div
        className={`relative flex w-[150px] flex-col items-center gap-2 rounded-2xl border-[3px] px-4 py-5 shadow-md transition-all duration-300 sm:w-[170px] ${
          pinned
            ? 'border-softwhite bg-forest text-pistachio shadow-lg shadow-forest/30'
            : 'border-softwhite bg-pistachio text-forest-deep shadow-forest/15'
        }`}
      >
        {/* push pin */}
        <span
          className={`absolute -top-2.5 left-1/2 flex h-6 w-6 -translate-x-1/2 items-center justify-center rounded-full shadow transition-all duration-300 ${
            pinned ? 'bg-coffee text-softwhite ring-2 ring-coffee/30' : 'bg-forest/20 text-forest/40'
          }`}
        >
          <Pin className="h-3 w-3" strokeWidth={2.5} />
        </span>
        <StickerArt kind={sticker.id} />
        <span className="font-serif text-[15px] font-semibold leading-tight">
          {sticker.label}
        </span>
        <span
          className={`text-[9px] font-semibold uppercase tracking-[0.2em] ${
            pinned ? 'text-cream/60' : 'text-forest-deep/55'
          }`}
        >
          {pinned ? 'Pinned' : 'Pin me'}
        </span>
      </div>
    </button>
  );
}

function StickerWall() {
  const { pinned, togglePin, todayCount, currentStreak, weekDone, rewardUnlocked } =
    useStreak();
  const status = rewardUnlocked ? 'Reward unlocked' : 'Ritual in progress';

  return (
    <Reveal delay={150}>
      <div className="mt-10 grid gap-8 lg:grid-cols-5">
        {/* Corkboard */}
        <div className="lg:col-span-3">
          <div className="relative rounded-3xl border border-coffee/20 bg-[#EAD9BC] p-6 shadow-inner sm:p-8">
            <div className="pointer-events-none absolute inset-2 rounded-2xl border border-coffee/15" />
            <div className="relative flex flex-wrap justify-center gap-5 py-2 sm:gap-6">
              {stickers.map((s) => (
                <StickerChip
                  key={s.id}
                  sticker={s}
                  pinned={pinned?.id === s.id}
                  onToggle={() => togglePin(s.id)}
                />
              ))}
            </div>
          </div>
          <p className="mt-3 text-center text-[11px] uppercase tracking-[0.2em] text-forest/40">
            Click a sticker to pin it to your ritual card
          </p>
        </div>

        {/* Member Ritual Card */}
        <div className="lg:col-span-2">
          <div className="relative overflow-hidden rounded-3xl bg-softwhite p-7 shadow-sm shadow-forest/10 sm:p-8">
            <div className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-sage via-pistachio to-coffee" />
            <h3 className="font-display text-xl font-semibold text-forest sm:text-2xl">
              Member Ritual Card
            </h3>
            {pinned ? (
              <>
                <div className="mt-5 flex items-center gap-4 rounded-2xl bg-cream p-4">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-forest text-pistachio">
                    <StickerArt kind={pinned.id} />
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-coffee">
                      Pinned Persona
                    </p>
                    <p className="font-serif text-xl font-semibold leading-tight text-forest">
                      {pinned.persona}
                    </p>
                  </div>
                </div>
                <p className="mt-4 text-[13px] leading-relaxed text-forest/60">
                  {pinned.note}
                </p>
              </>
            ) : (
              <div className="mt-5 rounded-2xl border border-dashed border-forest/20 p-5 text-center">
                <p className="font-serif text-lg italic text-forest/50">
                  No sticker pinned yet
                </p>
                <p className="mt-1.5 text-[13px] leading-relaxed text-forest/45">
                  Choose the sticker that feels most like you and pin it above.
                </p>
              </div>
            )}
            <div className="mt-6 space-y-2.5 border-t border-forest/10 pt-5">
              <div className="flex items-center justify-between text-sm">
                <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-forest/45">Today</span>
                <span className="font-medium text-forest">{todayCount} cup{todayCount === 1 ? '' : 's'} logged</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-forest/45">Streak</span>
                <span className="font-medium text-forest">{currentStreak} day{currentStreak === 1 ? '' : 's'}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-forest/45">Status</span>
                <span className="font-medium text-forest">{status}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Reveal>
  );
}
