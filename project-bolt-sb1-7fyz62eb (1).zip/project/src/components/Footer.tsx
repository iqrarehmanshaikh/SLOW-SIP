import { Instagram, Facebook, Twitter } from 'lucide-react';

const socials = [
  { icon: Instagram, label: 'Instagram', href: '#' },
  { icon: Facebook, label: 'Facebook', href: '#' },
  { icon: Twitter, label: 'Twitter', href: '#' },
];

const navGroups = [
  {
    title: 'Explore',
    links: [
      { label: 'Home', href: '#home' },
      { label: 'Play & Streak', href: '#play' },
      { label: 'Gallery', href: '#gallery' },
    ],
  },
  {
    title: 'Coffee',
    links: [
      { label: 'Menu', href: '#menu' },
      { label: 'Shop', href: '#shop' },
      { label: 'Contact', href: '#contact' },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="bg-forest-deep text-cream">
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8 sm:py-20">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <p className="font-display text-2xl font-semibold">
              SLOW SIP <span className="text-sm font-light uppercase tracking-[0.3em] text-cream/50">Coffee Co.</span>
            </p>
            <p className="mt-4 max-w-sm text-sm font-light leading-relaxed text-cream/60">
              A modern specialty coffee brand roasting small batches and pouring
              beautiful everyday rituals in Portland, Oregon.
            </p>
            <div className="mt-6 flex gap-3">
              {socials.map(({ icon: Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-cream/15 text-cream/70 transition-all duration-300 hover:border-pistachio hover:bg-pistachio hover:text-forest-deep"
                >
                  <Icon className="h-4 w-4" strokeWidth={1.7} />
                </a>
              ))}
            </div>
          </div>

          {navGroups.map((group) => (
            <div key={group.title}>
              <h3 className="text-[11px] font-semibold uppercase tracking-[0.25em] text-pistachio">
                {group.title}
              </h3>
              <ul className="mt-4 space-y-2.5">
                {group.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-cream/60 transition-colors hover:text-cream"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-cream/10 pt-8 sm:flex-row">
          <p className="text-[12px] text-cream/40">
            © {new Date().getFullYear()} SLOW SIP Coffee Co. All rights reserved.
          </p>
          <p className="font-serif text-sm italic text-cream/40">
            Slow coffee. Better moments.
          </p>
        </div>
      </div>
    </footer>
  );
}
