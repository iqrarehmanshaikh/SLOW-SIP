import { useEffect, useState } from 'react';
import { ShoppingBag, Menu, X } from 'lucide-react';
import { useCart } from '../context/CartContext';

const links = [
  { label: 'Home', href: '#home' },
  { label: 'Menu', href: '#menu' },
  { label: 'Shop', href: '#shop' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Play & Streak', href: '#play' },
  { label: 'Contact', href: '#contact' },
];

export default function Header() {
  const { count, openCart } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-40 px-4 pt-4 transition-all duration-500 sm:px-6 sm:pt-6 ${
          scrolled ? 'py-3' : ''
        }`}
      >
        <div
          className={`mx-auto flex max-w-[1240px] items-center justify-between rounded-[22px] px-5 py-4 shadow-sm transition-all duration-500 sm:px-8 ${
            scrolled
              ? 'bg-softwhite/95 py-3 shadow-forest/10 backdrop-blur-md'
              : 'bg-softwhite/90 backdrop-blur-sm'
          }`}
        >
          <a href="#home" className="group flex items-baseline gap-1.5">
            <span className="font-display text-xl font-semibold tracking-wide text-forest transition-colors duration-500 sm:text-2xl">
              SLOW SIP
            </span>
            <span className="hidden text-[9px] font-medium uppercase tracking-[0.3em] text-coffee sm:inline">
              Coffee Co.
            </span>
          </a>

          <nav className="hidden items-center gap-8 lg:flex">
            {links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="relative text-[12px] font-medium uppercase tracking-[0.18em] text-forest/80 transition-colors duration-500 after:absolute after:-bottom-1.5 after:left-0 after:h-px after:w-0 after:bg-current after:transition-all after:duration-300 hover:text-forest hover:after:w-full"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={openCart}
              aria-label="Open shopping cart"
              className="relative rounded-full p-2.5 text-forest transition-all duration-500 hover:scale-105 hover:bg-forest/5"
            >
              <ShoppingBag className="h-5 w-5" strokeWidth={1.8} />
              {count > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-coffee text-[10px] font-semibold text-softwhite shadow">
                  {count}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileOpen(true)}
              aria-label="Open menu"
              className="rounded-full p-2.5 text-forest transition-colors duration-500 hover:bg-forest/5 lg:hidden"
            >
              <Menu className="h-6 w-6" strokeWidth={1.8} />
            </button>
          </div>
        </div>
      </header>

      <div
        className={`fixed inset-0 z-50 transition-opacity duration-300 lg:hidden ${
          mobileOpen ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      >
        <div
          className="absolute inset-0 bg-forest-deep/60 backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />
        <div
          className={`absolute right-0 top-0 flex h-full w-[80%] max-w-sm flex-col bg-cream p-8 shadow-2xl transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] ${
            mobileOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="font-display text-xl font-semibold text-forest">SLOW SIP</span>
            <button
              onClick={() => setMobileOpen(false)}
              aria-label="Close menu"
              className="rounded-full p-2 text-forest hover:bg-forest/5"
            >
              <X className="h-6 w-6" strokeWidth={1.8} />
            </button>
          </div>
          <nav className="mt-12 flex flex-col gap-1">
            {links.map((link, i) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="border-b border-forest/10 py-4 font-serif text-3xl text-forest transition-all duration-300 hover:pl-3 hover:text-coffee"
                style={{ transitionDelay: `${i * 20}ms` }}
              >
                {link.label}
              </a>
            ))}
          </nav>
          <p className="mt-auto text-[12px] uppercase tracking-[0.25em] text-forest/50">
            Slow coffee. Better moments.
          </p>
        </div>
      </div>
    </>
  );
}
