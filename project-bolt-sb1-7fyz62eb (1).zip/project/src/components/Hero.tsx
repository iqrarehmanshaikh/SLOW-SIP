import { ArrowRight, Coffee, MoveDown } from 'lucide-react';
import Reveal from './Reveal';
import { HERO_IMAGE } from '../data';

export default function Hero() {
  return (
    <section id="home" className="bg-pistachio/70 px-3 pb-3 pt-3 sm:px-6 sm:pb-6 sm:pt-6">
      <div className="relative mx-auto flex min-h-[calc(100vh-1.5rem)] max-w-[1240px] items-center overflow-hidden rounded-[28px] bg-softwhite sm:min-h-[calc(100vh-3rem)]">
        <div className="pointer-events-none absolute -right-40 -top-44 h-[38rem] w-[38rem] rounded-full bg-cream/80 sm:-right-32 sm:-top-48" />
        <div className="pointer-events-none absolute bottom-[-22rem] right-[22%] h-[38rem] w-[38rem] rounded-full bg-pistachio/50" />

        <div className="relative z-10 grid w-full items-center gap-10 px-6 pb-16 pt-36 sm:px-12 sm:pb-20 lg:grid-cols-[1.03fr_0.97fr] lg:gap-4 lg:px-16 lg:pt-32">
          <div className="max-w-xl">
            <Reveal>
              <div className="flex items-center gap-3 text-[10px] font-semibold uppercase tracking-[0.32em] text-sage-dark sm:text-[11px]">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-pistachio text-forest">
                  <Coffee className="h-4 w-4" strokeWidth={1.8} />
                </span>
                Slow roasted · Carefully poured
              </div>
            </Reveal>

            <Reveal delay={120}>
              <h1 className="mt-7 max-w-2xl font-serif text-[15vw] font-medium leading-[0.94] tracking-[-0.03em] text-forest sm:text-7xl lg:text-[6.4rem]">
                Slow coffee
                <br />
                <span className="italic text-coffee">for better days.</span>
              </h1>
            </Reveal>

            <Reveal delay={240}>
              <p className="mt-7 max-w-md text-base font-light leading-relaxed text-forest/65 sm:text-lg">
                Specialty beans, thoughtful rituals and a little more time to
                enjoy the cup in front of you.
              </p>
            </Reveal>

            <Reveal delay={360}>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <a
                  href="#menu"
                  className="inline-flex items-center justify-center gap-3 rounded-xl bg-forest px-7 py-4 text-[12px] font-semibold uppercase tracking-[0.2em] text-cream shadow-lg shadow-forest/15 transition-all duration-300 hover:-translate-y-1 hover:bg-forest-deep hover:shadow-xl"
                >
                  Explore the menu
                  <ArrowRight className="h-4 w-4" />
                </a>
                <a
                  href="#play"
                  className="inline-flex items-center gap-2 rounded-xl px-4 py-4 text-[12px] font-semibold uppercase tracking-[0.16em] text-forest/70 transition-colors hover:text-forest"
                >
                  Your daily ritual
                  <MoveDown className="h-4 w-4" />
                </a>
              </div>
            </Reveal>
          </div>

          <Reveal delay={220} className="relative mx-auto w-full max-w-[480px] lg:ml-auto">
            <div className="relative mx-auto aspect-[0.78] w-[78%] overflow-hidden rounded-[48%] bg-cream shadow-2xl shadow-forest/15 sm:w-[68%] lg:w-[76%]">
              <img
                src={HERO_IMAGE}
                alt="Iced coffee latte in a clear glass with ice"
                className="h-full w-full object-cover object-center transition-transform duration-1000 hover:scale-105"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-forest-deep/35 via-transparent to-cream/10" />
            </div>
            <div className="absolute bottom-[8%] left-[3%] rounded-2xl border border-softwhite/70 bg-softwhite/90 px-4 py-3 shadow-lg backdrop-blur-sm sm:left-[8%]">
              <p className="text-[9px] font-semibold uppercase tracking-[0.22em] text-coffee">Today's pour</p>
              <p className="mt-1 font-serif text-lg italic text-forest">Iced oat latte</p>
            </div>
            <div className="absolute right-[2%] top-[10%] hidden rotate-6 rounded-full border border-forest/15 bg-pistachio px-4 py-4 text-center shadow-lg sm:block">
              <p className="font-display text-xl font-semibold text-forest">100%</p>
              <p className="text-[8px] font-semibold uppercase tracking-[0.18em] text-forest/65">coffee mood</p>
            </div>
          </Reveal>
        </div>

        <div className="absolute bottom-6 left-6 hidden items-center gap-3 text-[10px] font-semibold uppercase tracking-[0.26em] text-forest/40 sm:flex sm:left-12 lg:left-16">
          <span className="h-px w-8 bg-forest/30" />
          Portland · Est. 2019
        </div>
      </div>
    </section>
  );
}
