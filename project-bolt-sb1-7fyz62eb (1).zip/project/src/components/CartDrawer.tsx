import { useEffect, useState } from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, CheckCircle2 } from 'lucide-react';
import { useCart } from '../context/CartContext';
import CheckoutModal from './CheckoutModal';
import { formatPrice } from '../data';

export default function CartDrawer() {
  const { isOpen, closeCart, lines, total, grandTotal, discount, promoCode, setQty, remove, clear } = useCart();
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = isOpen || checkoutOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen, checkoutOpen]);

  const freeShippingAt = 4500;
  const progress = Math.min((total / freeShippingAt) * 100, 100);

  return (
    <>
      <div
        className={`fixed inset-0 z-50 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      >
        <div
          className="absolute inset-0 bg-forest-deep/60 backdrop-blur-sm"
          onClick={closeCart}
        />
        <aside
          className={`absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-softwhite shadow-2xl transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] ${
            isOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="flex items-center justify-between border-b border-forest/10 px-6 py-5">
            <div className="flex items-center gap-3">
              <ShoppingBag className="h-5 w-5 text-forest" strokeWidth={1.8} />
              <h2 className="font-display text-xl font-semibold text-forest">
                Your Cart
              </h2>
              {lines.length > 0 && (
                <span className="rounded-full bg-pistachio px-2.5 py-0.5 text-[11px] font-semibold text-forest-deep">
                  {lines.reduce((s, l) => s + l.qty, 0)}
                </span>
              )}
            </div>
            <button
              onClick={closeCart}
              aria-label="Close cart"
              className="rounded-full p-2 text-forest transition-colors hover:bg-forest/5"
            >
              <X className="h-5 w-5" strokeWidth={1.8} />
            </button>
          </div>

          {lines.length === 0 ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-cream">
                <ShoppingBag className="h-8 w-8 text-sage" strokeWidth={1.5} />
              </div>
              <p className="font-serif text-2xl text-forest">Your cart is empty</p>
              <p className="max-w-[240px] text-sm leading-relaxed text-forest/60">
                Your next favorite cup is waiting. Explore the menu and add something delicious.
              </p>
              <a
                href="#menu"
                onClick={closeCart}
                className="btn-primary mt-2"
              >
                Browse the Menu
              </a>
            </div>
          ) : (
            <>
              <div className="flex-1 overflow-y-auto px-6 py-4">
                <div className="mb-5 rounded-xl bg-cream p-4">
                  {total >= freeShippingAt ? (
                    <p className="flex items-center gap-2 text-[13px] font-medium text-forest">
                      <CheckCircle2 className="h-4 w-4 text-sage-dark" />
                      You've unlocked free pickup priority
                    </p>
                  ) : (
                    <p className="text-[13px] text-forest/70">
                      {formatPrice(freeShippingAt - total)} away from free pickup priority
                    </p>
                  )}
                  <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-forest/10">
                    <div
                      className="h-full rounded-full bg-sage transition-all duration-500"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

                <ul className="divide-y divide-forest/10">
                  {lines.map(({ product, qty }) => (
                    <li key={product.id} className="flex gap-4 py-4">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="h-20 w-20 shrink-0 rounded-xl object-cover"
                        loading="lazy"
                      />
                      <div className="flex flex-1 flex-col">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-serif text-lg font-semibold leading-tight text-forest">
                            {product.name}
                          </h3>
                          <button
                            onClick={() => remove(product.id)}
                            aria-label={`Remove ${product.name}`}
                            className="rounded-full p-1.5 text-forest/40 transition-colors hover:bg-red-50 hover:text-red-500"
                          >
                            <Trash2 className="h-4 w-4" strokeWidth={1.8} />
                          </button>
                        </div>
                        <p className="text-[13px] text-coffee">
                          {formatPrice(product.price)}
                        </p>
                        <div className="mt-auto flex items-center justify-between pt-2">
                          <div className="flex items-center gap-1 rounded-full border border-forest/15">
                            <button
                              onClick={() => setQty(product.id, qty - 1)}
                              aria-label="Decrease quantity"
                              className="rounded-full p-1.5 text-forest transition-colors hover:bg-forest/5"
                            >
                              <Minus className="h-3.5 w-3.5" />
                            </button>
                            <span className="w-6 text-center text-sm font-medium text-forest">
                              {qty}
                            </span>
                            <button
                              onClick={() => setQty(product.id, qty + 1)}
                              aria-label="Increase quantity"
                              className="rounded-full p-1.5 text-forest transition-colors hover:bg-forest/5"
                            >
                              <Plus className="h-3.5 w-3.5" />
                            </button>
                          </div>
                          <span className="text-sm font-semibold text-forest">
                            {formatPrice(product.price * qty)}
                          </span>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={clear}
                  className="mt-2 text-[12px] uppercase tracking-[0.15em] text-forest/40 transition-colors hover:text-forest"
                >
                  Clear cart
                </button>
              </div>

              <div className="border-t border-forest/10 px-6 py-5">
                <div className="mb-1 flex items-center justify-between text-sm text-forest/60">
                  <span>Subtotal</span>
                  <span>{formatPrice(total)}</span>
                </div>
                {promoCode && (
                  <div className="mb-1 flex items-center justify-between text-sm font-medium text-sage-dark">
                    <span className="flex items-center gap-1.5">
                      50% Ritual Reward
                      <span className="rounded-full bg-pistachio/50 px-2 py-0.5 text-[10px] font-bold tracking-wider text-forest-deep">
                        {promoCode}
                      </span>
                    </span>
                    <span>−{formatPrice(discount)}</span>
                  </div>
                )}
                <div className="mb-4 flex items-center justify-between">
                  <span className="font-display text-lg font-semibold text-forest">Total</span>
                  <span className="font-display text-xl font-semibold text-forest">
                    {formatPrice(grandTotal)}
                  </span>
                </div>
                <button onClick={() => setCheckoutOpen(true)} className="btn-primary w-full">
                  Checkout
                </button>
                <p className="mt-3 text-center text-[11px] uppercase tracking-[0.2em] text-forest/40">
                  Pickup at SLOW SIP — ready in 10 min
                </p>
              </div>
            </>
          )}
        </aside>
      </div>

      <CheckoutModal open={checkoutOpen} onClose={() => setCheckoutOpen(false)} />
    </>
  );
}
