import { CheckCircle2 } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function Toast() {
  const { toast } = useCart();
  if (!toast) return null;
  return (
    <div className="pointer-events-none fixed bottom-6 left-1/2 z-[70] -translate-x-1/2">
      <div className="animate-toast-in flex items-center gap-2.5 rounded-full bg-forest px-5 py-3 text-sm text-cream shadow-xl shadow-forest/30">
        <CheckCircle2 className="h-4 w-4 shrink-0 text-pistachio" />
        {toast}
      </div>
    </div>
  );
}
