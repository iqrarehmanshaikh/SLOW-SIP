import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';

export interface Sticker {
  id: string;
  label: string;
  persona: string;
  note: string;
  rotation: number;
}

export const stickers: Sticker[] = [
  {
    id: 'espresso-purist',
    label: 'Espresso Purist',
    persona: 'Espresso Purist',
    note: 'Short, intense and honest. Our single-origin pulled double is your home turf.',
    rotation: -6,
  },
  {
    id: 'iced-latte-lover',
    label: 'Iced Latte Lover',
    persona: 'Iced Latte Lover',
    note: 'Highlighting chilled espresso favorites — try the Iced Americano over extra ice.',
    rotation: 4,
  },
  {
    id: 'morning-ritualist',
    label: 'Morning Ritualist',
    persona: 'Morning Ritualist',
    note: 'First pour, same time, every day. The Cappuccino is your faithful companion.',
    rotation: -3,
  },
  {
    id: 'roast-explorer',
    label: 'Roast Explorer',
    persona: 'Roast Explorer',
    note: 'Always chasing the next origin. Ask about this month\u2019s guest single-origin.',
    rotation: 7,
  },
  {
    id: 'midnight-cold-brew',
    label: 'Midnight Cold Brew',
    persona: 'Midnight Cold Brew',
    note: '18-hour slow steep, zero rush. Our Cold Brew was made for your pace.',
    rotation: -5,
  },
  {
    id: 'latte-art-aficionado',
    label: 'Latte Art Aficionado',
    persona: 'Latte Art Aficionado',
    note: 'You drink with your eyes first. The Vanilla Latte pours a perfect tulip.',
    rotation: 5,
  },
  {
    id: 'cafe-regular',
    label: 'Café Regular',
    persona: 'Café Regular',
    note: 'The barista starts your order when you walk in. The Spanish Latte, as always.',
    rotation: -4,
  },
];

const LEVELS = [0, 1, 2, 3] as const;

export interface DayEntry {
  date: string; // YYYY-MM-DD
  count: number;
}

const DAYS_KEY = 'mm-streak-days';
const PIN_KEY = 'mm-pinned-sticker';

const toKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate()
  ).padStart(2, '0')}`;

const WEEKDAY_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Last `weeks` weeks of day-cells (columns), Mon-start rows, with month labels. */
function buildGrid(weeks: number) {
  const today = new Date();
  today.setHours(23, 59, 59, 999);
  const end = new Date(today);
  // snap to Saturday of current week (end of grid)
  end.setDate(end.getDate() + (6 - ((end.getDay() + 6) % 7)));
  const start = new Date(end);
  start.setDate(end.getDate() - (weeks * 7 - 1));
  // snap start to Monday
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7));

  const columns: { key: string; date: Date; future: boolean }[][] = [];
  const monthLabels: { index: number; label: string }[] = [];
  let lastMonth = -1;
  const cursor = new Date(start);
  for (let w = 0; w < weeks * 2; w++) {
    const col: { key: string; date: Date; future: boolean }[] = [];
    for (let d = 0; d < 7; d++) {
      if (cursor > end) break;
      col.push({
        key: toKey(cursor),
        date: new Date(cursor),
        future: cursor > today,
      });
      if (d === 0 && cursor.getMonth() !== lastMonth) {
        lastMonth = cursor.getMonth();
        monthLabels.push({ index: w, label: WEEKDAY_SHORT[lastMonth] });
      }
      cursor.setDate(cursor.getDate() + 1);
    }
    if (col.length) columns.push(col);
    if (cursor > end) break;
  }
  return { columns, monthLabels };
}

const fromKey = (key: string) => {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, m - 1, d);
};

function loadDays(): Record<string, number> {
  try {
    const raw = localStorage.getItem(DAYS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return typeof parsed === 'object' && parsed !== null ? parsed : {};
  } catch {
    return {};
  }
}

function loadPin(): string | null {
  try {
    return localStorage.getItem(PIN_KEY);
  } catch {
    return null;
  }
}

export function levelOf(count: number): (typeof LEVELS)[number] {
  if (count >= 3) return 3;
  if (count === 2) return 2;
  if (count === 1) return 1;
  return 0;
}

export const levelStyles: Record<number, string> = {
  0: 'bg-[#E5DFD0]',
  1: 'bg-pistachio',
  2: 'bg-sage',
  3: 'bg-forest',
};

export const levelText: Record<number, string> = {
  0: 'No coffees',
  1: '1 coffee',
  2: '2 coffees',
  3: '3+ coffees',
};

// Monday → Saturday labels
export const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** Monday of the current week (local time) */
function mondayOf(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay(); // 0 = Sunday
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

export interface StreakContextValue {
  days: Record<string, number>;
  todayCount: number;
  logCoffees: (n: number) => void;
  simulateDemo: () => void;
  resetDemo: () => void;
  currentStreak: number;
  totalCoffees: number;
  week: boolean[]; // index 0 = Mon … 5 = Sat
  weekDone: boolean;
  rewardUnlocked: boolean;
  promoCode: string | null;
  pinned: Sticker | null;
  togglePin: (id: string) => void;
}

const StreakContext = createContext<StreakContextValue | null>(null);

export function StreakProvider({ children }: { children: ReactNode }) {
  const [days, setDays] = useState<Record<string, number>>(() => loadDays());
  const [pinnedId, setPinnedId] = useState<string | null>(() => loadPin());

  useEffect(() => {
    try {
      localStorage.setItem(DAYS_KEY, JSON.stringify(days));
    } catch {
      /* storage unavailable — state stays in memory */
    }
  }, [days]);

  useEffect(() => {
    try {
      if (pinnedId) localStorage.setItem(PIN_KEY, pinnedId);
      else localStorage.removeItem(PIN_KEY);
    } catch {
      /* ignore */
    }
  }, [pinnedId]);

  const todayKey = toKey(new Date());

  const logCoffees = (n: number) => {
    if (n <= 0) return;
    setDays((prev) => ({ ...prev, [todayKey]: Math.min((prev[todayKey] ?? 0) + n, 9) }));
  };

  const simulateDemo = () => {
    setDays((prev) => {
      const next = { ...prev };
      const monday = mondayOf(new Date());
      // Fill Mon → Sat of this week (demo caps at the days that have passed,
      // plus any already logged, so the grid reads naturally)
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      for (let i = 0; i < 6; i++) {
        const day = new Date(monday);
        day.setDate(monday.getDate() + i);
        if (day > today) break;
        const key = toKey(day);
        next[key] = Math.max(next[key] ?? 0, 1);
      }
      // Always log today so the demo shows movement
      next[todayKey] = Math.max(next[todayKey] ?? 0, 1);
      return next;
    });
  };

  const resetDemo = () => setDays({});

  const currentStreak = useMemo(() => {
    // consecutive days with ≥1 coffee, ending today or yesterday
    const cursor = new Date();
    cursor.setHours(0, 0, 0, 0);
    if (!days[toKey(cursor)]) {
      cursor.setDate(cursor.getDate() - 1);
      if (!days[toKey(cursor)]) return 0;
    }
    let streak = 0;
    while (days[toKey(cursor)]) {
      streak++;
      cursor.setDate(cursor.getDate() - 1);
    }
    return streak;
  }, [days]);

  const week = useMemo(() => {
    const monday = mondayOf(new Date());
    return weekDays.map((_, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      return (days[toKey(d)] ?? 0) > 0;
    });
  }, [days]);

  const weekDone = week.every(Boolean);

  const totalCoffees = useMemo(
    () => Object.values(days).reduce((s, n) => s + n, 0),
    [days]
  );

  const pinned = useMemo(
    () => stickers.find((s) => s.id === pinnedId) ?? null,
    [pinnedId]
  );

  const togglePin = (id: string) =>
    setPinnedId((prev) => (prev === id ? null : id));

  const value: StreakContextValue = {
    days,
    todayCount: days[todayKey] ?? 0,
    logCoffees,
    simulateDemo,
    resetDemo,
    currentStreak,
    totalCoffees,
    week,
    weekDone,
    rewardUnlocked: weekDone,
    promoCode: weekDone ? 'RITUAL50' : null,
    pinned,
    togglePin,
  };

  return <StreakContext.Provider value={value}>{children}</StreakContext.Provider>;
}

export function useStreak(): StreakContextValue {
  const ctx = useContext(StreakContext);
  if (!ctx) throw new Error('useStreak must be used within StreakProvider');
  return ctx;
}

export { toKey, fromKey, buildGrid, WEEKDAY_SHORT };
