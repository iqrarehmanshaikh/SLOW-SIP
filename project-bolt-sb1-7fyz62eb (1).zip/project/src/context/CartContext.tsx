import { createContext, useContext, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type { Product } from '../data';
import { products } from '../data';
import { useStreak } from './StreakContext';

export interface CartLine {
  product: Product;
  qty: number;
}

interface CartContextValue {
  lines: CartLine[];
  count: number;
  total: number;
  discount: number;
  grandTotal: number;
  promoCode: string | null;
  isOpen: boolean;
  toast: string | null;
  add: (product: Product) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  openCart: () => void;
  closeCart: () => void;
  showToast: (message: string) => void;
}

const CartContext = createContext<CartContextValue | null>(null);

let toastTimer: ReturnType<typeof setTimeout> | undefined;

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Record<string, number>>({});
  const [isOpen, setIsOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const { rewardUnlocked, promoCode, logCoffees } = useStreak();

  const showToast = (message: string) => {
    setToast(message);
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => setToast(null), 2600);
  };

  const add = (product: Product) => {
    setItems((prev) => ({ ...prev, [product.id]: (prev[product.id] ?? 0) + 1 }));
    logCoffees(1);
    showToast(`${product.name} added to your cart`);
  };

  const remove = (id: string) =>
    setItems((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });

  const setQty = (id: string, qty: number) => {
    if (qty <= 0) {
      remove(id);
      return;
    }
    setItems((prev) => ({ ...prev, [id]: Math.min(qty, 99) }));
  };

  const clear = () => setItems({});

  const lines = useMemo<CartLine[]>(
    () =>
      Object.entries(items)
        .map(([id, qty]) => {
          const product = products.find((p) => p.id === id);
          return product ? { product, qty } : null;
        })
        .filter((l): l is CartLine => l !== null),
    [items]
  );

  const count = lines.reduce((sum, l) => sum + l.qty, 0);
  const total = lines.reduce((sum, l) => sum + l.qty * l.product.price, 0);
  const discount = rewardUnlocked ? total * 0.5 : 0;
  const grandTotal = total - discount;

  const value: CartContextValue = {
    lines,
    count,
    total,
    discount,
    grandTotal,
    promoCode: rewardUnlocked ? promoCode : null,
    isOpen,
    toast,
    add,
    remove,
    setQty,
    clear,
    openCart: () => setIsOpen(true),
    closeCart: () => setIsOpen(false),
    showToast,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
