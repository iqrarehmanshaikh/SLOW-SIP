import Header from './components/Header';
import Hero from './components/Hero';
import BestSellers from './components/BestSellers';
import Menu from './components/Menu';
import WhyChooseUs from './components/WhyChooseUs';
import Gallery from './components/Gallery';
import PlayStreak from './components/PlayStreak';
import Contact from './components/Contact';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import Toast from './components/Toast';
import { CartProvider } from './context/CartContext';
import { StreakProvider } from './context/StreakContext';
import { Coffee } from 'lucide-react';

function Marquee() {
  const items = ['Freshly Roasted', 'Single Origin', 'Brewed to Order', 'Farm Direct', 'Est. 2019'];
  const row = [...items, ...items, ...items];
  return (
    <div className="overflow-hidden border-y border-forest/10 bg-pistachio/30 py-4">
      <div className="flex w-max animate-[marquee_30s_linear_infinite] gap-10">
        {row.map((item, i) => (
          <span
            key={i}
            className="flex items-center gap-10 whitespace-nowrap text-[11px] font-semibold uppercase tracking-[0.3em] text-forest/70"
          >
            {item}
            <Coffee className="h-3.5 w-3.5 text-coffee" />
          </span>
        ))}
      </div>
      <style>{`@keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-33.333%); } }`}</style>
    </div>
  );
}

export default function App() {
  return (
    <StreakProvider>
      <CartProvider>
        <Header />
        <main>
          <Hero />
          <Menu />
          <BestSellers />
          <Gallery />
          <WhyChooseUs />
          <PlayStreak />
          <Contact />
        </main>
        <Footer />
        <CartDrawer />
        <Toast />
      </CartProvider>
    </StreakProvider>
  );
}
